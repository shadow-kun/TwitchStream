<?php defined('_JEXEC') or die; 
// No direct access ?>
	<div style="left:-27.5%; position: relative;">
		<iframe src="http://www.twitch.tv/<?php echo $streamer; ?>/chat?popout=" frameborder="0" scrolling="no" style="left:-50px; width: 300px; height: 480px; transform:scale(0.65,1); left: -50px;"></iframe>
	</div>