<?php defined('_JEXEC') or die; 
// No direct access ?>
	<iframe src="http://www.twitch.tv/<?php echo $streamer; ?>/chat?popout=" frameborder="0" scrolling="no" style="position: relative; min-width: 300px; width: 300px; height: 480px; left: -38px; top: -60px;
		 transform:scale(0.75);"></iframe>
